/**
 * @file 销售管道配置控制器
 */
import * as svc from '../services/pipelineConfig.service.js';

/** GET /api/pipeline/config — 获取当前管道配置 */
export async function getConfig(req, res) {
  const tenantId = req.tenantId;
  const config = await svc.getPipelineConfig(tenantId);
  res.json({ data: config });
}

/** GET /api/pipeline/stages — 获取管道阶段列表（仅用于看板） */
export async function getStages(req, res) {
  const tenantId = req.tenantId;
  const stages = await svc.getPipelineStages(tenantId);
  res.json({ data: stages });
}

/** PUT /api/pipeline/config — 保存管道配置 */
export async function saveConfig(req, res) {
  const tenantId = req.tenantId;
  const { stages } = req.body;
  if (!stages) {
    return res.status(400).json({ error: '缺少 stages 参数' });
  }
  const result = await svc.savePipelineConfig(tenantId, stages);
  res.json({ data: result });
}

/** POST /api/pipeline/reset — 重置为默认管道 */
export async function resetConfig(req, res) {
  const tenantId = req.tenantId;
  const result = await svc.resetPipelineConfig(tenantId);
  res.json({ data: result });
}

/** GET /api/pipeline/templates — 获取管道模板列表 */
export async function listTemplates(req, res) {
  const templates = svc.getPipelineTemplates();
  res.json({ data: templates });
}

/** POST /api/pipeline/templates/:key/apply — 应用管道模板 */
export async function applyTemplate(req, res) {
  const tenantId = req.tenantId;
  const { key } = req.params;
  const result = await svc.applyPipelineTemplate(tenantId, key);
  res.json({ data: result });
}
