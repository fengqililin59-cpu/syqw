/**
 * @file 套餐计费路由。
 */
import { Router } from 'express';
import { requireAuth } from '../middlewares/auth.js';
import { requirePerm } from '../middlewares/requirePerm.js';
import { requirePlatformAdmin } from '../middlewares/requirePlatformAdmin.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import * as billingController from '../controllers/billing.controller.js';

const router = Router();

router.get('/plans', asyncHandler(billingController.getPlans));
router.get('/payment/channels', asyncHandler(billingController.getPaymentChannels));

router.post(
  '/webhooks/wechat',
  asyncHandler(billingController.wechatPayWebhook),
);
router.post(
  '/webhooks/wechat/mock',
  asyncHandler(billingController.wechatPayMockWebhook),
);
router.post('/webhooks/alipay', asyncHandler(billingController.alipayPayWebhook));
router.post('/webhooks/alipay/mock', asyncHandler(billingController.alipayPayMockWebhook));

router.get('/wechat/mp-oauth-callback', asyncHandler(billingController.wechatMpOAuthCallback));

router.use(requireAuth);
router.get(
  '/wechat/jsapi-ready',
  requirePerm('settings:manage'),
  asyncHandler(billingController.getWechatJsapiReady),
);
router.get(
  '/wechat/mp-oauth-url',
  requirePerm('settings:manage'),
  asyncHandler(billingController.getWechatMpOAuthUrl),
);
router.get('/subscription', asyncHandler(billingController.getSubscription));
router.get('/usage', asyncHandler(billingController.getUsage));

router.post('/subscription', requirePlatformAdmin, asyncHandler(billingController.upsertSubscription));
router.post('/payment', requirePerm('settings:manage'), asyncHandler(billingController.createPayment));
router.get(
  '/payment/:outTradeNo/status',
  requirePerm('settings:manage'),
  asyncHandler(billingController.getPaymentStatus),
);
router.post('/payment/confirm', requirePlatformAdmin, asyncHandler(billingController.confirmPayment));
router.get('/payments', requirePerm('settings:manage'), asyncHandler(billingController.listPayments));
router.get(
  '/statement/export',
  requirePerm('settings:manage'),
  asyncHandler(billingController.exportSubscriptionStatement),
);
router.get(
  '/payments/pending-online',
  requirePerm('settings:manage'),
  asyncHandler(billingController.listPendingOnlinePayments),
);
router.post('/redeem', requirePerm('settings:manage'), asyncHandler(billingController.redeemPromo));
router.get(
  '/invoice-requests',
  requirePerm('settings:manage'),
  asyncHandler(billingController.listInvoiceRequests),
);
router.post(
  '/invoice-requests',
  requirePerm('settings:manage'),
  asyncHandler(billingController.createInvoiceRequest),
);

router.get('/platform/pending-payments', requirePlatformAdmin, asyncHandler(billingController.listPendingPaymentsPlatform));
router.get('/platform/promo-codes', requirePlatformAdmin, asyncHandler(billingController.listPromoCodes));
router.post('/platform/promo-codes', requirePlatformAdmin, asyncHandler(billingController.createPromoCode));

export default router;
