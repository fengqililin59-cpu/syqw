/**
 * @file 支付宝当面付（trade.precreate 扫码）+ 异步通知验签。
 */
import crypto from 'crypto';
import dayjs from 'dayjs';
import { env } from '../config/env.js';
import { HttpError } from '../utils/httpError.js';

const GATEWAY_PROD = 'https://openapi.alipay.com/gateway.do';
const GATEWAY_SANDBOX = 'https://openapi-sandbox.dl.alipaydev.com/gateway.do';

function normalizePem(raw, label) {
  const s = String(raw || '').replace(/\\n/g, '\n').trim();
  if (!s) return null;
  if (s.includes('BEGIN')) return s;
  const body = s.replace(/\s/g, '');
  const lines = body.match(/.{1,64}/g) || [];
  return `-----BEGIN ${label}-----\n${lines.join('\n')}\n-----END ${label}-----`;
}

function loadPrivateKey() {
  return normalizePem(env.alipay.privateKey, 'RSA PRIVATE KEY');
}

function loadPublicKey() {
  return normalizePem(env.alipay.publicKey, 'PUBLIC KEY');
}

export function isAlipayConfigured() {
  if (env.alipay.mock) return true;
  return Boolean(
    env.alipay.appId &&
      loadPrivateKey() &&
      loadPublicKey() &&
      env.alipay.notifyBaseUrl,
  );
}

export function isAlipayMock() {
  return env.alipay.mock === true;
}

function gatewayUrl() {
  return env.alipay.sandbox ? GATEWAY_SANDBOX : GATEWAY_PROD;
}

function signParams(params) {
  const privateKey = loadPrivateKey();
  if (!privateKey) throw new HttpError(503, '未配置支付宝应用私钥', 503);

  const sorted = Object.keys(params)
    .filter((k) => params[k] !== '' && params[k] != null && k !== 'sign')
    .sort()
    .map((k) => `${k}=${params[k]}`)
    .join('&');

  return crypto.createSign('RSA-SHA256').update(sorted, 'utf8').sign(privateKey, 'base64');
}

function verifySign(params) {
  const publicKey = loadPublicKey();
  if (!publicKey) return false;
  const sign = params.sign;
  if (!sign) return false;
  const sorted = Object.keys(params)
    .filter((k) => params[k] !== '' && params[k] != null && k !== 'sign' && k !== 'sign_type')
    .sort()
    .map((k) => `${k}=${params[k]}`)
    .join('&');
  return crypto.createVerify('RSA-SHA256').update(sorted, 'utf8').verify(publicKey, sign, 'base64');
}

async function gatewayRequest(method, bizContent) {
  const notifyUrl = `${env.alipay.notifyBaseUrl.replace(/\/$/, '')}/api/v1/billing/webhooks/alipay`;
  const params = {
    app_id: env.alipay.appId,
    method,
    format: 'JSON',
    charset: 'utf-8',
    sign_type: 'RSA2',
    timestamp: dayjs().format('YYYY-MM-DD HH:mm:ss'),
    version: '1.0',
    notify_url: notifyUrl,
    biz_content: JSON.stringify(bizContent),
  };
  params.sign = signParams(params);

  const res = await fetch(gatewayUrl(), {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8' },
    body: new URLSearchParams(params),
  });

  const text = await res.text();
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    console.error('[alipay] invalid gateway response', text.slice(0, 500));
    throw new HttpError(502, '支付宝网关响应异常', 502);
  }

  const respKey = `${method.replace(/\./g, '_')}_response`;
  const payload = data[respKey] || {};
  if (payload.code !== '10000') {
    const msg = payload.sub_msg || payload.msg || '支付宝下单失败';
    console.error('[alipay] precreate failed', payload);
    throw new HttpError(502, msg, 502);
  }
  return payload;
}

/**
 * 当面付预下单，返回 qr_code（用于生成扫码）。
 */
export async function createPrecreateOrder({ outTradeNo, subject, totalAmountYuan }) {
  if (env.alipay.mock) {
    const qr = `https://qr.alipay.com/MOCK_${encodeURIComponent(outTradeNo)}`;
    return { qr_code: qr, mock: true };
  }

  const payload = await gatewayRequest('alipay.trade.precreate', {
    out_trade_no: String(outTradeNo),
    total_amount: Number(totalAmountYuan).toFixed(2),
    subject: String(subject || 'ZhiFlow套餐').slice(0, 256),
  });

  if (!payload.qr_code) throw new HttpError(502, '支付宝未返回支付二维码', 502);
  return { qr_code: payload.qr_code, mock: false };
}

function parseNotifyBody(rawBody, bodyObj) {
  if (bodyObj && typeof bodyObj === 'object' && bodyObj.out_trade_no) return bodyObj;
  const params = {};
  const raw = String(rawBody || '');
  if (!raw) return params;
  for (const part of raw.split('&')) {
    const [k, v] = part.split('=');
    if (!k) continue;
    params[decodeURIComponent(k)] = decodeURIComponent((v || '').replace(/\+/g, ' '));
  }
  return params;
}

/**
 * 解析支付宝异步通知（application/x-www-form-urlencoded）。
 */
export function parsePayNotification(rawBody, bodyObj) {
  const params = parseNotifyBody(rawBody, bodyObj);

  if (!params.out_trade_no) {
    return { handled: false, reason: 'missing_out_trade_no' };
  }

  if (!isAlipayMock() && !verifySign(params) && !env.alipay.skipSignatureVerify) {
    throw new HttpError(401, '支付宝通知验签失败', 401);
  }

  const tradeStatus = params.trade_status;
  const success = tradeStatus === 'TRADE_SUCCESS' || tradeStatus === 'TRADE_FINISHED';
  if (!success) {
    return { handled: false, out_trade_no: params.out_trade_no, trade_status: tradeStatus };
  }

  return {
    handled: true,
    out_trade_no: params.out_trade_no,
    trade_no: params.trade_no,
    total_amount: params.total_amount,
  };
}
