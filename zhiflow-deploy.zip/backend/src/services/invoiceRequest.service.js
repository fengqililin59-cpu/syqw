/**
 * @file 租户开票申请与平台处理。
 */
import Joi from 'joi';
import { Op } from 'sequelize';
import {
  BillingInvoiceRequest,
  PaymentRecord,
  Plan,
  Tenant,
  User,
} from '../models/index.js';
import { HttpError } from '../utils/httpError.js';
import { paginated } from '../utils/response.js';
import { isSmtpConfigured, sendMail } from './mail.service.js';
import { env } from '../config/env.js';

const INVOICE_TYPE_LABELS = {
  vat_special: '增值税专用发票',
  vat_normal: '增值税普通发票',
  electronic: '电子普通发票',
};

const STATUS_LABELS = {
  pending: '待处理',
  processing: '处理中',
  issued: '已开票',
  rejected: '已驳回',
};

const createSchema = Joi.object({
  invoice_type: Joi.string().valid('vat_special', 'vat_normal', 'electronic').default('electronic'),
  title: Joi.string().trim().min(2).max(200).required(),
  tax_no: Joi.string().trim().min(15).max(32).required(),
  amount: Joi.number().positive().max(9999999).optional(),
  email: Joi.string().trim().email().max(120).required(),
  mailing_address: Joi.string().trim().max(255).allow('', null).optional(),
  remark: Joi.string().trim().max(500).allow('', null).optional(),
  payment_record_id: Joi.number().integer().positive().optional(),
}).unknown(false);

const updateSchema = Joi.object({
  status: Joi.string().valid('pending', 'processing', 'issued', 'rejected').required(),
  admin_remark: Joi.string().trim().max(500).allow('', null).optional(),
}).unknown(false);

function mapRow(row) {
  const p = row.get ? row.get({ plain: true }) : row;
  const {
    Tenant: tenantRow,
    PaymentRecord: payRow,
    requester: requesterRow,
    ...rest
  } = p;
  return {
    ...rest,
    amount: Number(rest.amount),
    invoice_type_label: INVOICE_TYPE_LABELS[rest.invoice_type] || rest.invoice_type,
    status_label: STATUS_LABELS[rest.status] || rest.status,
    tenant: tenantRow ? { id: tenantRow.id, name: tenantRow.name } : null,
    payment: payRow
      ? {
          id: payRow.id,
          out_trade_no: payRow.out_trade_no,
          amount: Number(payRow.amount),
          paid_at: payRow.paid_at,
          plan_name: payRow.plan?.name,
        }
      : null,
    requester: requesterRow
      ? {
          id: requesterRow.id,
          username: requesterRow.username,
          real_name: requesterRow.real_name,
        }
      : null,
  };
}

const includeOpts = [
  { model: Tenant, attributes: ['id', 'name'] },
  {
    model: PaymentRecord,
    required: false,
    attributes: ['id', 'out_trade_no', 'amount', 'paid_at', 'status'],
    include: [{ model: Plan, as: 'plan', attributes: ['name'], required: false }],
  },
  { model: User, as: 'requester', attributes: ['id', 'username', 'real_name'], required: false },
];

export async function createInvoiceRequest(auth, body) {
  const { error, value } = createSchema.validate(body || {}, { abortEarly: false, stripUnknown: true });
  if (error) throw new HttpError(400, '参数校验失败', 400, error.details);

  const tenantId = Number(auth.tenantId);
  let amount = value.amount != null ? Number(value.amount) : null;
  let paymentRecordId = value.payment_record_id ? Number(value.payment_record_id) : null;

  if (paymentRecordId) {
    const pay = await PaymentRecord.findOne({
      where: { id: paymentRecordId, tenant_id: tenantId, status: 'paid' },
    });
    if (!pay) throw new HttpError(400, '关联订单不存在或未支付', 400);
    if (amount == null) amount = Number(pay.amount);
  }

  if (amount == null || amount <= 0) {
    const lastPaid = await PaymentRecord.findOne({
      where: { tenant_id: tenantId, status: 'paid' },
      order: [['paid_at', 'DESC']],
    });
    if (!lastPaid) throw new HttpError(400, '请填写开票金额或先完成一笔付款', 400);
    amount = Number(lastPaid.amount);
    paymentRecordId = paymentRecordId || lastPaid.id;
  }

  if (value.invoice_type === 'vat_special' && !String(value.mailing_address || '').trim()) {
    throw new HttpError(400, '增值税专用发票需填写邮寄地址', 400);
  }

  const pending = await BillingInvoiceRequest.count({
    where: { tenant_id: tenantId, status: { [Op.in]: ['pending', 'processing'] } },
  });
  if (pending >= 3) {
    throw new HttpError(400, '当前待处理开票申请较多，请等待平台处理后再提交', 400);
  }

  const row = await BillingInvoiceRequest.create({
    tenant_id: tenantId,
    requested_by: auth.userId,
    payment_record_id: paymentRecordId,
    invoice_type: value.invoice_type,
    title: value.title,
    tax_no: value.tax_no,
    amount,
    email: value.email,
    mailing_address: value.mailing_address || null,
    remark: value.remark || null,
    status: 'pending',
  });

  const full = await BillingInvoiceRequest.findByPk(row.id, { include: includeOpts });
  return mapRow(full);
}

export async function listTenantInvoiceRequests(auth, query = {}) {
  const page = Math.max(1, Number(query.page) || 1);
  const size = Math.min(50, Math.max(1, Number(query.size) || 20));

  const { rows, count } = await BillingInvoiceRequest.findAndCountAll({
    where: { tenant_id: Number(auth.tenantId) },
    include: includeOpts,
    order: [['id', 'DESC']],
    limit: size,
    offset: (page - 1) * size,
  });

  return paginated(rows.map(mapRow), count, page, size);
}

export async function listPlatformInvoiceRequests(query = {}) {
  const page = Math.max(1, Number(query.page) || 1);
  const size = Math.min(100, Math.max(1, Number(query.size) || 30));
  const where = {};
  if (query.status && STATUS_LABELS[query.status]) where.status = query.status;

  const { rows, count } = await BillingInvoiceRequest.findAndCountAll({
    where,
    include: includeOpts,
    order: [['id', 'DESC']],
    limit: size,
    offset: (page - 1) * size,
  });

  return paginated(rows.map(mapRow), count, page, size);
}

export async function updatePlatformInvoiceRequest(requestId, body) {
  const { error, value } = updateSchema.validate(body || {}, { abortEarly: false, stripUnknown: true });
  if (error) throw new HttpError(400, '参数校验失败', 400, error.details);

  const row = await BillingInvoiceRequest.findByPk(Number(requestId), { include: includeOpts });
  if (!row) throw new HttpError(404, '申请不存在', 404);

  const patch = {
    status: value.status,
    admin_remark: value.admin_remark ?? row.admin_remark,
  };
  if (value.status === 'issued') patch.issued_at = new Date();

  await row.update(patch);
  const updated = await BillingInvoiceRequest.findByPk(row.id, { include: includeOpts });
  const mapped = mapRow(updated);

  if (isSmtpConfigured() && ['issued', 'rejected'].includes(value.status)) {
    const subject =
      value.status === 'issued'
        ? `【ZhiFlow】发票已开具 · ¥${mapped.amount}`
        : `【ZhiFlow】开票申请未通过`;
    const text = [
      `您好，`,
      value.status === 'issued'
        ? `您提交的开票申请（${mapped.invoice_type_label}，¥${mapped.amount}）已处理完成。`
        : `您提交的开票申请未能通过：${value.admin_remark || '请联系平台客服'}`,
      mapped.admin_remark && value.status === 'issued' ? `备注：${mapped.admin_remark}` : '',
      '',
      `抬头：${mapped.title}`,
      `税号：${mapped.tax_no}`,
      '',
      `${env.appUrl.replace(/\/$/, '')}/app/billing`,
    ]
      .filter(Boolean)
      .join('\n');
    await sendMail({ to: mapped.email, subject, text }).catch((e) => {
      console.warn('[invoice] notify tenant email failed', e?.message);
    });
  }

  return mapped;
}

export async function countPendingInvoiceRequests() {
  return BillingInvoiceRequest.count({ where: { status: 'pending' } });
}
